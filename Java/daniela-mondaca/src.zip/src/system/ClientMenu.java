package system;
import personClass.Person;
import system.Mainframe;

public class ClientMenu implements ClientMenuInterface{
	public void userMenu(Person person, SinglyLinkedList texts, SinglyLinkedList bookings,
						 SinglyLinkedList devolutions) {
		System.out.println("Point reached User");
	}
	
	public void workerMenu(Person person, SinglyLinkedList texts, SinglyLinkedList bookings,
			 			   SinglyLinkedList devolutions) {
		System.out.println("Point reached worker");
	}
	
	
}

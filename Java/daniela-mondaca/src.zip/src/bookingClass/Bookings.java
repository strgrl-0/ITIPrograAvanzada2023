package bookingClass;

public class Bookings {
	private int bookingCode;
	private String associatedRut;
	private int objectCode;
	private String bookingDate;
	private String returnDate;
	
	public Bookings (int bookingCode, String associatedRut, int objectCode, 
					String bookingDate, String returnDate) {
		this.bookingCode = bookingCode;
		this.associatedRut = associatedRut;
		this.objectCode = objectCode;
		this.bookingDate = bookingDate;
		this.returnDate = returnDate;
	}
}

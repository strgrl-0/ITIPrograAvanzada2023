"""
Bastian Guerra Valdés, ITI , Ejercicio 1 clase 3
"""
x = 0
z = 0
num1 = 0
num2 = 0
suma = 0

print("Ciclo For")
for i in range(0,5):
    pass # Pasa este bloque de comando
    print(i)
 
print("------------")    
    
print("Ciclo While")
while x < 5 :
    x = x + 1
    print(x)

print("Imprimir numeros impares")  

for num1 in range(1,50,2):
    print(num1)
    
for z in range(1,101,1):
    suma = suma + z
    print(suma)
    
    
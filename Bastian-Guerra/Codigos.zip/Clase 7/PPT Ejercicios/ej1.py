"""
Clase 7 ejercicios PPT, ej1
"""

arch = open("nombres1.txt","r",encoding = "utf-8")
linea = arch.readline().strip().lower()
lista = []

while linea != "":
    nombre = str(linea)
    lista.append(nombre)
    linea = arch.readline().strip().lower()
    


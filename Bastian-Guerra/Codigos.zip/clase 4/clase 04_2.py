"""
Bastian Guerra Valdes, ITI
"""

texto = "Hola,chao"
partes = texto.split(",")
inicio = partes[0]
fin = partes[1]

print("el inicio es",inicio)
print("el fin es",fin)

texto = "1,2,3,4"
partes = texto.split(",")

print(partes[0])
print(partes[1])
print(partes[2])
print(partes[3])


"""
Bastian Guerra ITI
"""
a = input()
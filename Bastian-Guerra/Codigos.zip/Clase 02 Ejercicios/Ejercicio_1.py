"""
Bastian Guerra Valdes,ITI,Clase 2
"""
"""
Comencemos con algo sencillo. Crea dos variables, asígnale valores numéricos y realiza todas las operaciones aritméticas que viste en la clase. Asigna los resultados a variables diferentes. 
Luego imprime todos los resultados concatenados entre si. 
Prueba desplegar el promedio de los resultados.
"""

a = 3
b = 2

sum = a + b
rest = a - b
mul = a * b
exp = a ** b
div = a / b
mod = a // b
modulo = a % b

print(sum, rest, mul, exp, div, mod ,modulo)
all = (sum, rest, mul, exp, div, mod ,modulo) / 7
print("El promedio de todos los valores es: ",all)